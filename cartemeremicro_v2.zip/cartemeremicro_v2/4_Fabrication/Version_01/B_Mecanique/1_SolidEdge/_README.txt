Les fichiers solidedge doivent �tre plac�s ici 

(NE PAS UTILISER LA VERSION EDUCATION !)
