Placer ici TOUT LES fichiers m�caniques utiles pour la fabrication du projet

Choisir le m�me nom pour les ficher .STL et .par ! 

Exemple: 

roue_v1.par � placer dans 1_SolidEdge
roue_v1.STL � placer dans 2_STL