Les fichiers stl doivent �tre plac�s ici
