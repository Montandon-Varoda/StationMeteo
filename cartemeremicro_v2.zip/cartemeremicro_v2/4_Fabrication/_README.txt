La premi�re version de vos fichier de fabrication doit s'appeler Version "0". 

Dans le cas o� il y a des modifications importantes de votre Design, 
il est n�cessaire de GARDER TOUTES LES VERSIONS. 

Il faudra donc Copier/Coller/Renommer le dossier de la premi�re version et 
d'effectuer les modifications de design sur une NOUVELLE VERSION. 
