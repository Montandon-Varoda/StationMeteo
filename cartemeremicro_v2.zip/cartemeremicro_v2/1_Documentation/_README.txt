A placer dans ce dossier: 

- Le lien vers le xWiki
https://xwiki.serverelo.org/xwiki/bin/view/Centre%20de%20Formation%20ELO/Travaux-diplome/TPI_Goumaz_Carte_m%C3%A8re_micro_V2/
- Le fichier .pdf g�n�r� par l'article xWiki
