A placer dans ce dossier: 

- Les mesures importantes de la carte



Peu �tre sous forme de tableau (ou feuille Excel) ou bien sous forme d'image (ou scan)
